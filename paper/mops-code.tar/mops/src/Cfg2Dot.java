// $Id: Cfg2Dot.java,v 1.7 2002/10/07 01:19:00 hchen Exp $

import java.io.*;
import gnu.getopt.*;

/**
 * User application to visualize CFG
 */
public class Cfg2Dot
{
  private static void usage()
  {
    System.err.println("Usage: Cfg2Dot [-a] [-d] [-v] cfg_filename dot_filename");
  }
  
  public static void main(String args[]) throws IOException
  {
    Cfg cfg = new Cfg();
    String cfgFilename = null, dotFilename = null;
    boolean isWriteAst = false;
    Getopt opt;
    int ch;

    opt = new Getopt("Cfg2Dot", args, "adv");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'a':
	  isWriteAst = true;
	  break;

	case 'd':
	  Util.setDebug(true);
	  break;

	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) != 2)
    {
      usage();
      System.exit(1);
    }
    cfgFilename = args[opt.getOptind()];
    dotFilename = args[opt.getOptind() + 1];
    cfg.read(cfgFilename);
    cfg.writeToDot(dotFilename, isWriteAst);
  }
}
