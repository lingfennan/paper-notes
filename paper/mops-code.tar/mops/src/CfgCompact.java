// $Id: CfgCompact.java,v 1.12 2002/10/07 01:19:00 hchen Exp $

import java.io.*;
import java.util.*;
import gnu.getopt.*;

/**
 * End user application to compact a CFG
 */
public class CfgCompact
{
  private static void usage()
  {
    System.err.println(
        "Usage: CfgCompact [-d] [-v] mfsa_filename input_cfg entry_function output_cfg");
  }
  
  public static void main(String args[]) throws IOException
  {
    Cfg cfg = new Cfg();
    String cfgInFilename = null, cfgOutFilename = null, mfsaFilename = null,
      entryFunctionName = null;
    MetaFsa metaFsa;
    // Calendar calendar;
    Getopt opt;
    int ch;

    opt = new Getopt("CfgCompact", args, "dv");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'd':
	  Util.setDebug(true);
	  break;
	  
	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) != 4) 
    {
      usage();
      System.exit(1);
    }
    
    mfsaFilename = args[opt.getOptind()];
    cfgInFilename = args[opt.getOptind() + 1];
    entryFunctionName = args[opt.getOptind() + 2];
    cfgOutFilename = args[opt.getOptind() + 3];

    metaFsa = new MetaFsa();
    metaFsa.read(mfsaFilename);
    //calendar = new GregorianCalendar();
    //System.err.println("Reading cfg " + calendar.getTime());
    cfg.read(cfgInFilename);
    //calendar = new GregorianCalendar();
    //System.err.println("Compacting cfg " + calendar.getTime());
    cfg.compact(metaFsa, entryFunctionName);
    //calendar = new GregorianCalendar();
    //System.err.println("Writing cfg " + calendar.getTime());
    cfg.write(cfgOutFilename);
    //calendar = new GregorianCalendar();
    //System.err.println("Done " + calendar.getTime());
  }
}
