// $Id: CfgFunction.java,v 1.4 2001/08/30 22:00:35 hchen Exp $

/**
 * Represent a function declaration in CFG
 */
class CfgFunction
{
  /**
   * Entry node
   */
  public Node entry;

  /**
   * Exit node
   */
  public Node exit;

  /**
   * Function name
   */
  public String label;

  /**
   * The root Ast of this function
   */
  public Ast ast;

  /**
   * The parent CFG
   */
  public Cfg cfg;
}

