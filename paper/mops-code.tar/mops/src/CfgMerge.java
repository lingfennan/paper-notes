// $Id: CfgMerge.java,v 1.7 2002/10/07 01:19:00 hchen Exp $

import java.io.*;
import gnu.getopt.*;

/**
 * End user application to merge several CFGs
 */
public class CfgMerge
{
  private static void usage()
  {
    System.err.println(
	"Usage: CfgMerge [-d] [-v] output_cfg_file cfg_file+");
  }
  
  public static void main(String args[]) throws IOException
  {
    Cfg cfg;
    String[] fileNames;
    String outputFileName;
    Getopt opt;
    int i, ch;

    opt = new Getopt("CfgMerge", args, "dv");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'd':
	  Util.setDebug(true);
	  break;

	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) < 2)
    {
      usage();
      System.exit(1);
    }
    outputFileName = args[opt.getOptind()];
    fileNames = new String[args.length - opt.getOptind() - 1];
    for (i = opt.getOptind() + 1; i < args.length; i++)
      fileNames[i - opt.getOptind() - 1] = args[i];
    
    cfg = Cfg.merge(fileNames);
    cfg.write(outputFileName);
  }
}
