// $Id: Check.java,v 1.17 2002/10/09 05:00:04 hchen Exp $

import java.io.*;
import java.util.*;
import gnu.getopt.*;

/**
 * User application to check for reachability of some states, or all
 * statements that may be executed in these states.
 */
public class Check
{
  private static void usage()
  {
    System.err.println(
      "Usage: Check [-p] meta_fsa_filename pda_cfg_filename entry_function_name outout_filename");
  }
  
  public static void main(String[] args) throws IOException
  {
    Getopt opt;
    int ch;
    boolean isProgramPoint = false;
    
    opt = new Getopt("Check", args, "dvp");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'p':
	  isProgramPoint = true;
	  break;
	  
	case 'd':
	  Util.setDebug(true);
	  break;

	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) != 4)
    {
      usage();
      System.exit(1);
    }
    new Check().run(args[opt.getOptind()], args[opt.getOptind() + 1],
		    args[opt.getOptind() + 2], args[opt.getOptind() + 3],
		    isProgramPoint);
  }

  /**
   * @param list False: check for state reachability.  True: Gather
   * all statements that may be executed in these states
   */
  public void run(String metaFsaFilename, String cfgFilename,
		  String entryFunctionName, String outputFilename,
		  boolean list)
    throws IOException
  {
    Pda pda, pda2;
    Fsa fsa, fsa2;
    Cfg cfg;
    Vector initialTransitions;
    MetaFsa metaFsa;
    Iterator iter;
    int i, j, count;
    String filename;
    // for debug purpose only
    Vector variables;
    // for debug purpose only
    Variable variable;

    // read in CFG
    cfg = new Cfg();
    cfg.read(cfgFilename);

    // construct PDA from CFG
    pda = new Pda();
    pda.read(cfg, entryFunctionName);
    //System.out.println("pda:");
    //pda.print();

    // read in MetaFsa
    metaFsa = new MetaFsa();
    metaFsa.read(metaFsaFilename);

    // variable instantiation
    metaFsa.resolveVariable(cfg);

    // this part is for debugging purposes only
    if (Util.getDebug())
    {
      variables = metaFsa.getVariables();
      if (variables.size() == 0)
	System.out.println("No variable is found/matched.");
      else
	for (i = 0; i < variables.size(); i++)
	{
	  variable = (Variable)variables.get(i);
	  System.out.println("Variable " + i + ": in " + variable.instances.size() +
			     " Ast nodes");
	  for (j = 0; j < variable.instances.size(); j++)
	    System.out.println(j + ": " + (Ast)variable.instances.get(j));
	}
    }
    
    // For each instance of MetaFsa, compose it with Pda
    count = 0;
    iter = metaFsa.iterator();
    while (iter.hasNext())
    {
      System.out.println(
	 "Checking the program against an instance of the property:");
      // in fact, iter.next() always returns the same object
      // but its internal data have been changed
      metaFsa = (MetaFsa)iter.next();
      // Compose pda with metaFsa
      pda2 = pda.compose(metaFsa);
      //System.out.println("fsa:");
      //fsa.print();

      // post() and poststar() operation
      fsa2 = pda2.post();
      //System.out.println("fsa2:");
      //fsa2.print();

      initialTransitions = fsa2.findInitialTransitions();
      if (!list)
      // decide if final states are reachable
      {
	if (initialTransitions.size() == 0)
	  System.out.println("The program satisfies the property.");
	else
	{
	  if (count == 0)
	    filename = outputFilename;
	  else
	    filename = outputFilename + "." + count;
	  System.out.println("The program violates the property.  An offending trace was written to the file " + filename + ".");
	  count++;
	  fsa2.writeBacktrackPath(initialTransitions, filename);
	}
      }
      else
      // print out all statements that may be executed in final states
      {
	if (count == 0)
	  filename = outputFilename;
	else
	  filename = outputFilename + "." + count;
	System.out.println("The file " + filename +
			   " contains all the program points that may execute in any final state of the FSA");
	count++;
	fsa2.writeInitialTransitions(initialTransitions, filename);
      }
    }
  }
}


