// $Id: Fsa2Dot.java,v 1.11 2002/10/07 01:19:01 hchen Exp $

import java.io.*;
import gnu.getopt.*;

/**
 * User application to visualize model FSA
 */
public class Fsa2Dot
{
  private static void usage()
  {
    System.err.println("Usage: Fsa2Dot [-l] [-d] [-v] fsa_file dot_file");
  }
  
  public static void main(String[] args) throws IOException
  {
    Fsa fsa;
    String fsaFilename, dotFilename;
    boolean printLabel = false;
    Getopt opt;
    int ch;

    opt = new Getopt("Fsa2Dot", args, "dvl");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'l':
	  printLabel = true;
	  break;
	  
	case 'd':
	  Util.setDebug(true);
	  break;

	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) != 2)
    {
      usage();
      System.exit(1);
    }
    fsaFilename = args[opt.getOptind()];
    dotFilename = args[opt.getOptind() + 1];
    fsa = new Fsa();
    fsa.read(fsaFilename);
    fsa.writeToDot(dotFilename, printLabel);
  }
}



