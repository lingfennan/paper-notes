// $Id: StateLabel.java,v 1.3 2001/08/30 22:00:37 hchen Exp $

import java.util.*;

/**
 * Contains labels in a dimension in the FSA/PDA state space
 */
public class StateLabel
{
  /**
   * size of this dimension
   */
  public int size;
  /**
   * labels in this dimension.  Each element is a String
   */
  public HashMap labels;

  public StateLabel()
  {
    size = 0;
    labels = null;
  }

  public StateLabel(int size, HashMap labels)
  {
    this.size = size;
    this.labels = labels;
  }
}

