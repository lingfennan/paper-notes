import java.io.*;
import gnu.getopt.*;

/**
 * User application to transform the output from check of a compacted
 * CFG into an uncompacted CFG
 */
public class Transform
{
  private static void usage()
  {
    System.err.println("Usage: Transform [-p] [-d] [-v] cfg_filename trace_file_name output_filename");
  }
  
  public static void main(String[] args) throws IOException
  {
    Cfg cfg = new Cfg();
    String cfgFilename, traceFilename, outputFilename;
    boolean isProgramPoint = false;
    Getopt opt;
    int ch;

    opt = new Getopt("Transform", args, "dvp");
    while ((ch = opt.getopt()) != -1)
    {
      switch(ch)
      {
	case 'p':
	  isProgramPoint = true;
	  break;
	  
	case 'd':
	  Util.setDebug(true);
	  break;

	case 'v':
	  Util.printVersion();
	  System.exit(0);
	  
	default:
	  usage();  
          System.exit(1);
      }
    }
    if ((args.length - opt.getOptind()) != 3)
    {
      usage();
      System.exit(1);
    }
    
    cfgFilename = args[opt.getOptind()];
    traceFilename = args[opt.getOptind() + 1];
    outputFilename = args[opt.getOptind() + 2];
    cfg.read(cfgFilename);
    if (!isProgramPoint)
      // input is a trace (output from Fsa.writeBacktrackPath())
      cfg.transformPath(traceFilename, outputFilename);
    else
      // input is a list of nodes (output from Fsa.writeInitialTransitions())
      cfg.transformTransitions(traceFilename, outputFilename);
  }
}
