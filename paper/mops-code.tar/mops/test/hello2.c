#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <pwd.h>

void drop_priv()
{
  struct passwd *passwd;

  seteuid(getuid());
  if ((passwd = getpwuid(getuid())) == NULL)
  {
    printf("getpwuid() failed");
    return;
  }
  printf("Drop user %s's privilege\n", passwd->pw_name);
}

int main(int argc, char *argv[])
{
  drop_priv();
  printf("About to exec\n");
  execv(argv[1], argv + 1);
}
