#include <stdio.h>
#include <unistd.h>

void drop_priv();

int main(int argc, char *argv[])
{
  drop_priv();
  printf("About to exec\n");
  execv(argv[1], argv + 1);
}
