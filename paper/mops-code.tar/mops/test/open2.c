#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int a, b;
  
  a = open(argv[1], O_RDONLY);
  b = open(argv[2], O_RDONLY);
  if (a == -1 || b == -1)
  {
    perror("open()");
    exit(1);
  }
  close(a);
  close(b);
}
